const port = 3000;
const dbName = 'wizzardCreatures';
const SECRET = '4ab79e76-06ab-4396-a599-5f7f89872cbe'

module.exports = {
    port,
    dbName,
    SECRET,
}