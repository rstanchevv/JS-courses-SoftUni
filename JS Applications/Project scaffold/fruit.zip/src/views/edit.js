import { editFruit, getAFruit } from "../api/data.js";
import { html, nothing } from "../lib.js";

const editTemplate = (fruit, onSubmit) => html`<section id="edit">
  <div class="form">
    <h2>Edit Fruit</h2>
    <form @submit=${onSubmit} class="edit-form">
      <input type="text" name="name" id="name" placeholder="" value ="${fruit.name}"/>
      <input
        type="text"
        name="imageUrl"
        id="Fruit-image"
        placeholder=""
        value = "${fruit.imageUrl}"
      />
      <textarea
        id="fruit-description"
        name="description"
        placeholder=""
        rows="10"
        cols="50"
      >${fruit.description}</textarea>
      <textarea 
        id="fruit-nutrition"
        name="nutrition"
        placeholder=""
        rows="10"
        cols="50"
      >${fruit.nutrition}</textarea>
      <button type="submit">post</button>
    </form>
  </div>
</section> `;

export async function showEdit(ctx) {
  const id = ctx.params.id;
  const fruit = await getAFruit(id);
  ctx.render(editTemplate(fruit, onSubmit));

  async function onSubmit(e) {

    e.preventDefault();
    const formData = new FormData(e.target);
    const { name, imageUrl, description, nutrition} = Object.fromEntries(formData);
    if (
      name.length < 1 ||
      imageUrl.length < 1 ||
      description.length < 1 ||
      nutrition.length < 1
    ) {
      alert(`All fields must be filled out!`);
    } else {
      await editFruit(id, {
        _id: fruit._id,
        _ownerId: fruit._ownerId,
        name,
        imageUrl,
        description,
        nutrition,
      });
      ctx.page.redirect(`/details/${id}`);
    }
  }
}
