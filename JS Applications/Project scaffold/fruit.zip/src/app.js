import {page, render} from './lib.js';
import { showCatalog } from './views/catalog.js';
import { showDetails } from './views/details.js';
import { showHome } from './views/home.js';
import { showLogin } from './views/login.js';
import { registerView } from './views/register.js';
import { updateNav } from './views/nav.js';
import { getUserData } from './api/util.js';
import { createView } from './views/create.js';
import { showEdit } from './views/edit.js';
import { searchView } from './views/search.js';
const main = document.querySelector('main')

// document.getElementById('logout').addEventListener('click', onLogout);

page(decorateContext)
page('/', showHome)
page('/search', searchView)
page('/dashboard', showCatalog)
page('/login', showLogin)
page('/create', createView)
page('/register', registerView);
page('/details/:id', showDetails);
page('/edit/:id', showEdit)


updateNav()
page.start();

function decorateContext(ctx, next){
    ctx.render = renderMain;
    ctx.updateNav = updateNav;
    const user = getUserData();
    if (user){
        ctx.user = user;
    }
    next();
}

function renderMain(content) {
    render(content, main)
}



