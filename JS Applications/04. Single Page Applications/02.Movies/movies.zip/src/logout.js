import { showMoviesSection } from "./home.js";

export async function onLogout() {
  const token = JSON.parse(sessionStorage.getItem("userData")).token;
  try {
    const res = await fetch("http://localhost:3000/users/login", {
      method: "GET",
      headers: {
        "X-Authorization": token,
      },
    });
    if (res.status === 204) {
      sessionStorage.clear();
      alert("Logout successful");
      showMoviesSection();
    }
  } catch (err) {
    alert(err);
  }
}
