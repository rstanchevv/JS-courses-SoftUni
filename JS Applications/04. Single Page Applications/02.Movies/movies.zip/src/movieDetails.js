export async function showDetails(e) {
  e.preventDefault();
  if (e.target.tagName == "BUTTON") {
    const movieId = e.target.parentElement.getAttribute("href");
    const movieSection = document.getElementById(movieId);
    Array.from(document.querySelectorAll("section")).forEach(
      (x) => (x.style.display = "none")
    );
    movieSection.style.display = "block";
    const fetchMovie = await loadDetailsBasedOnOwnership(movieId);
    console.log(fetchMovie)
    if (JSON.parse(sessionStorage.getItem("userData")).id != fetchMovie._ownerId) {
      movieSection.querySelector(".btn-danger").style.display = "none";
      movieSection.querySelector(".btn-warning").style.display = "none";
    }
  }
}

async function loadDetailsBasedOnOwnership(id) {
  try {
    const res = await fetch(`http://localhost:3000/data/movies/${id}`);
    if (res.ok != true) {
      const error = await res.json();
      throw new Error(error.message);
    }
    const data = await res.json();
    return data;
  } catch (err) {
    alert(err);
  }
}

// async function getLikes(id){
//   const res = await fetch(`http://localhost:3000/data/likes?where=movieId%3D%22${id}%22&distinct=_ownerId&count`)
//   const data = await res.json();
// }
