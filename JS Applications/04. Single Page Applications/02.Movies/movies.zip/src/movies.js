const movieList = document.querySelector('#movies-list');
document.querySelector('#movie-example').remove()
const container = document.querySelector('.container')

async function getMovies(){
    const res = await fetch('http://localhost:3000/data/movies')
    const data = await res.json();
    return data;
}

export async function loadMovies(){
    movieList.replaceChildren()
    document.querySelectorAll('.movie-example').forEach(x => x.remove());
    
    const movies = await getMovies();
    for (const movie of movies) {
        const div = document.createElement('div');
        div.innerHTML = `                    <div class="card mb-4">
        <img class="card-img-top" src="${movie.img}"
             alt="Card image cap" width="400">
        <div class="card-body">
            <h4 class="card-title">${movie.title}</h4>
        </div>
        <div class="card-footer">
            <a href="${movie._id}">
                <button type="button" class="btn btn-info">Details</button>
            </a>
        </div>`
        movieList.appendChild(div)   

        const movieDetails = document.createElement('section');
        movieDetails.classList.add('movie-example')
        movieDetails.id = movie._id
        movieDetails.innerHTML = `<div class="container">
        <div class="row bg-light text-dark">
          <h1>Movie title: ${movie.title}</h1>

          <div class="col-md-8">
            <img
              class="img-thumbnail"
              src="${movie.img}"
              alt="Movie"
            />
          </div>
          <div class="col-md-4 text-center">
            <h3 class="my-3">Movie Description</h3>
            <p>
              ${movie.description}
            </p>
            <a class="btn btn-danger" href="#">Delete</a>
            <a class="btn btn-warning" href="#">Edit</a>
            <a class="btn btn-primary" href="#">Like</a>
            <span class="enrolled-span">Liked 1</span>
          </div>
        </div>
      </div>`
      container.appendChild(movieDetails);
    }
}

