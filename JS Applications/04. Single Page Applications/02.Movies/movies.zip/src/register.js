import { showMoviesSection } from "./home.js";

const registerSection = document.querySelector("#form-sign-up");
const registerForm = document.querySelector("#register-form");
registerForm.addEventListener("submit", register);
export function showRegisterSection() {
  Array.from(document.querySelectorAll("section")).forEach(
    (x) => (x.style.display = "none")
  );
  registerSection.style.display = "block";
}

async function register(e) {
  e.preventDefault();
  const formData = new FormData(e.target);
  const { email, password, repeatPassword } = Object.fromEntries(formData);
  try {
    if (email && password && repeatPassword) {
      if (password === repeatPassword && password.length >= 6) {
          const res = await fetch("http://localhost:3000/users/register", {
            method: "post",
            headers: {
              "Content-type": "application/json",
            },
            body: JSON.stringify({ email, password }),
          });
          if (res.ok != true) {
            const error = await res.json();
            throw new Error(error.message);
          }
          const data = await res.json();
          console.log(data);
          const token = data.accessToken;
          sessionStorage.setItem("userData", JSON.stringify({ email, token }));
          e.target.reset();
          alert("Registration successful");
          showMoviesSection();
      } else {
        throw new Error("Password and Repeat password must match and the password should be at least 6 symbols.");
      }
    } else {
      throw new Error('All fields must be filled out.')
    }
  } catch (err) {
    alert(err);
  }
}
