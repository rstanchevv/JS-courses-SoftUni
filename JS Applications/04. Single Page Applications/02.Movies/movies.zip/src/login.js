import { showMoviesSection } from "./home.js";

const loginSection = document.querySelector('#form-login');
const loginForm = document.querySelector('#login-form')
loginForm.addEventListener('submit', login);
export function showLoginSection(){
    Array.from(document.querySelectorAll('section')).forEach(x => x.style.display = 'none');
    loginSection.style.display = 'block';
}

async function login(e){
    e.preventDefault();
    const formData = new FormData(e.target);
    const {email, password} = Object.fromEntries(formData)
    try {
        if (email && password) {
            try{
                const res = await fetch('http://localhost:3000/users/login', {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({email, password})
            });
            if (res.ok != true){
                const error = await res.json();
                throw new Error(error.message)
            }
            const data = await res.json();
            sessionStorage.setItem('userData', JSON.stringify({email: data.email, id: data._id, token: data.accessToken}))
            alert("Login successful");
            showMoviesSection()
            } catch(err){
                alert(err)
            }
        } else {
            throw new Error ('All fields must be filled out.')
        }
    } catch(err) {
        alert(err)
    }
}

