import { showMoviesSection } from "./home.js";

const addMovieSection = document.querySelector('#add-movie');
const addMovieForm = document.querySelector('#add-movie-form');

addMovieForm.addEventListener('submit', onAdd)


export function displayAddMovie(){
    Array.from(document.querySelectorAll('section')).forEach(x => x.style.display = 'none');
    addMovieSection.style.display = 'block'
}

async function onAdd(e){
    e.preventDefault();
    const token = JSON.parse(sessionStorage.getItem('userData')).token
    const id = JSON.parse(sessionStorage.getItem('userData')).id
    const formData = new FormData(e.target);
    const {title, description, img} = Object.fromEntries(formData);
    if(title, description, img){
        try{
            const res = await fetch('http://localhost:3000/data/movies',{
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Authorization': token
                },
                body: JSON.stringify({title, description, img, id})
            })
            if (res.ok != true){
                const error = await res.json();
                throw new Error(error.message)
            }
            showMoviesSection()
        } catch(err){
            alert(err);
        }
    }
}

