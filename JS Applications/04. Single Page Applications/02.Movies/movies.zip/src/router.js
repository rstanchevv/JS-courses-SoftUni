import { displayAddMovie } from "./addMovie.js";
import { showMoviesSection } from "./home.js";
import { showLoginSection } from "./login.js";
import { onLogout } from "./logout.js";
import { showRegisterSection } from "./register.js";

const routes = {
    'Movies': showMoviesSection,
    'Login': showLoginSection,
    'Register': showRegisterSection,
    'Logout' : onLogout,
    'Add Movie': displayAddMovie,
}

export function onNavbarClick(e){
    if (e.target.tagName == 'A'){
        e.preventDefault()
        const currentClick = e.target.textContent;
        try {
        const routing = routes[currentClick]
        routing()
        } catch(err){
            alert(`Not found!`)
        }
    }
}