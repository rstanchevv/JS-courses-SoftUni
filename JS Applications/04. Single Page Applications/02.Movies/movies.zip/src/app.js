import { showMoviesSection } from "./home.js";
import { showDetails } from "./movieDetails.js";
import { onNavbarClick } from "./router.js"
document.addEventListener('click', onNavbarClick)
document.querySelector('#movies-list').addEventListener('click', showDetails)
showMoviesSection()


