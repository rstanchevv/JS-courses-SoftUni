import { loadMovies } from "./movies.js";
await loadMovies()
const homeSection = document.querySelector('#home-page');
const welcomeMsg =  document.querySelector('#welcome-msg');
const movieSection = document.querySelector('#movie');
export async function showMoviesSection(){
    Array.from(document.querySelectorAll('section')).forEach(x => x.style.display = 'none');
    homeSection.style.display = 'block';
    sessionStorage.getItem('userData') === null ? displayGuest() : displayUser()
}
function displayUser(){
    const userData = JSON.parse(sessionStorage.getItem('userData'))
    Array.from(document.querySelectorAll('.user')).forEach(x => x.style.display = 'block')
    Array.from(document.querySelectorAll('.guest')).forEach(x => x.style.display = 'none');
    [...document.querySelectorAll('.btn-info')].forEach(x => x.disabled = false)
    movieSection.style.display = 'block'
    welcomeMsg.textContent = userData.email
}
function displayGuest(){
    [...document.querySelectorAll('.btn-info')].forEach(x => x.disabled = true)
    Array.from(document.querySelectorAll('.user')).forEach(x => x.style.display = 'none')
    Array.from(document.querySelectorAll('.guest')).forEach(x => x.style.display = 'block')
    movieSection.style.display = 'block'
}